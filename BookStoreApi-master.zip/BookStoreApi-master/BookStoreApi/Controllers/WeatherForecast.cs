﻿
namespace BookStoreApi.Controllers
{
    public class WeatherForecast
    {
        public DateOnly Date { get; internal set; }
        public int TemperatureC { get; internal set; }
        public string Summary { get; internal set; }
    }
}